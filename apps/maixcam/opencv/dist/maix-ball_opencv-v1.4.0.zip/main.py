"""
MaixCAM：OpenCV 钢珠位置 → UART → balance 摆杆主控（闭环停球）
         + 本机屏 HUD + 可选手机 MJPEG 双显

对接文档：
  apps/balance/docs/vision_proto.md
  apps/balance/src/Hardware/Inc/ball_proto.h

算法：
  - 固定凹槽 ROI + 灰度/轮廓/1D 投影
  - 像素 → 相对 O 的 mm，**整 mm** 量化上报（type=0x02）

帧（定长 13B，小端）：
  球位 0x02: AA 55 | 02 | flags | pos_mm i16 | cx i16 | cy i16 | conf | mode | csum
  定点 0x12: AA 55 | 12 | 00 | target_mm i16 | pad×6 | csum
  pos/target 单位 = **1 mm**（整毫米，抑抖）；csum=sum(body)&0xFF

WiFi：
  已连接 → 直接用现有网络；未连接 → 扫码（可 Skip）
  无 WiFi 时禁用 MJPEG；主页 Menu 可手动重连

MJPEG（有 WiFi 时）：
  http://<MaixIP>:8000/stream  （/ 同流，带 HUD 叠加）

接线 3.3V 共地：
  MaixCAM A16 TX → balance PA31 (UART0 RX)
  MaixCAM A17 RX → balance PA28 (可选)
  MaixCAM2: A21/A22 → UART4
"""

from maix import camera, display, image, app, time, touchscreen, sys, err
import re
import socket
import struct
import threading
import time as pytime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

print("[ball] boot...")

try:
    import cv2
    import numpy as np
    print("[ball] cv2 ok", cv2.__version__ if hasattr(cv2, "__version__") else "")
except Exception as e:
    print("[ball] import cv2 FAIL:", e)
    raise

try:
    from maix import pinmap, uart
    HAS_UART_MOD = True
except Exception as e:
    print("[ball] uart module missing:", e)
    HAS_UART_MOD = False

# ---------- 与 ball_proto / vision_proto 对齐 ----------
ENABLE_UART = True
PROTO_MAGIC0 = 0xAA
PROTO_MAGIC1 = 0x55
PROTO_TYPE_BALL = 0x02
PROTO_TYPE_SETPOINT = 0x12
PROTO_FLAG_FOUND = 0x01
# 与 MCU BALL_CONF_MIN 一致：低于此视为丢球
CONF_MIN = 30
TX_MIN_MS = 20            # ≤50 Hz，MCU 超时 100 ms
BAUD = 115200

CAM_W, CAM_H = 320, 240

# ---------- WiFi 扫码（无硬编码 SSID/密码）----------
WIFI_CONNECT_TIMEOUT = 60

# ---------- MJPEG 推流（仅在有有效 WiFi 时启用）----------
ENABLE_MJPEG = True       # 总开关；运行时还需 _stream_ready
HTTP_PORT = 8000
JPEG_QUALITY = 45
MJPEG_EVERY_N = 1         # 每 N 帧提交编码；2 可减负（质量不变）
DISP_EVERY_N = 2          # 本机 LCD 每 N 帧刷新；图传/检测不受影响

_mjpeg_lock = threading.Lock()
_mjpeg_jpeg = None
_mjpeg_stop = False
_mjpeg_server = None
_mjpeg_clients = 0
_mjpeg_pending = None
_mjpeg_pending_lock = threading.Lock()
_mjpeg_wake = threading.Event()
_stream_ready = False     # True = 有 WiFi 且 MJPEG 服务已起
_wifi_ip = ""

# ---------- 统一 UI 色板 ----------
UI_BG = (36, 36, 48)
UI_BG_ACTIVE = (40, 90, 70)
UI_BG_DANGER = (70, 36, 36)
UI_BG_ACCENT = (36, 56, 88)
UI_BORDER = (200, 200, 210)
UI_BORDER_ACTIVE = (80, 220, 140)
UI_BORDER_DANGER = (220, 100, 100)
UI_TEXT_DIM = (160, 160, 170)
UI_ROI = (80, 180, 255)
UI_O = (255, 220, 80)
UI_SP = (255, 64, 180)
UI_SP_DIM = (160, 80, 140)
UI_FPS = (120, 200, 255)
UI_OK = (80, 220, 140)

# 凹槽 ROI：用户已标定＝完整有效行程（勿改四数）
# 中线=O；品红线=停球定点；球=小点
ROI_X, ROI_Y, ROI_W, ROI_H = 33, 130, 260, 14
BAR_LEN_MM = 234.0          # 框内左右总长实测
O_OFFSET_PX = ROI_W // 2
SP_MIN_MM = int(-BAR_LEN_MM * 0.5)
SP_MAX_MM = int(BAR_LEN_MM * 0.5)

ENABLE_PROJ_FALLBACK = True
PROJ_MIN_CONTRAST = 10.0
PROJ_SCORE_SCALE = 2.0

DETECT_MODE = 1
TH_BRIGHT = 200
TH_DARK = 115
TH_BAR_WHITE = 120
MIN_AREA = 12
MAX_AREA = 500
MIN_CIRCULARITY = 0.28
MAX_ASPECT = 2.4
BALL_DIAM_PX = 12
POS_ALPHA = 0.35
Y_CENTER_WEIGHT = 20.0
POS_HYST_MM = 0.55
TRACK_VEL_ALPHA = 0.35
TRACK_MAX_JUMP_MM = 28.0
TRACK_HOLD_FRAMES = 1

MODE_NAMES = ("BRI", "DRK", "AUT")

# OpenCV 形态学核（热路径复用，避免每帧 getStructuringElement）
_K_CLOSE = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
_K_OPEN = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2, 2))
_K_BAR_DIL = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 5))
_K_BAR = cv2.getStructuringElement(
    cv2.MORPH_RECT, (5, max(2, min(3, ROI_H // 4)))
)


def _rgb(rgb):
    return image.Color.from_rgb(rgb[0], rgb[1], rgb[2])


def _wifi_unescape(s):
    out = []
    i = 0
    while i < len(s):
        if s[i] == "\\" and i + 1 < len(s):
            out.append(s[i + 1])
            i += 2
            continue
        out.append(s[i])
        i += 1
    return "".join(out)


def wifi_current_ip():
    """已连接且 IP 有效则返回 ip，否则 None。"""
    try:
        from maix import network
        w = network.wifi.Wifi()
        connected = False
        try:
            connected = bool(w.is_connected())
        except Exception:
            connected = False
        ip = ""
        try:
            ip = w.get_ip() or ""
        except Exception:
            ip = ""
        if (not ip) or ip in ("0.0.0.0", "127.0.0.1"):
            ip = get_ip()
        # 有效局域网 IP 即视为可用（部分固件 is_connected 不可靠）
        if ip and ip not in ("0.0.0.0", "127.0.0.1"):
            if connected:
                return ip
            # 未报告 connected 但仍有 wlan IP，也接受
            return ip
        if connected:
            ip = get_ip()
            if ip and ip not in ("0.0.0.0", "127.0.0.1"):
                return ip
    except Exception as e:
        print("[ball] wifi_current_ip:", e)
    ip = get_ip()
    if ip and ip not in ("0.0.0.0", "127.0.0.1"):
        return ip
    return None


def parse_wifi_qr(payload):
    """
    解析 WiFi 二维码 → (ssid, password) 或 None。
    支持：
      WIFI:T:WPA;S:ssid;P:pass;;
      WIFI:T:nopass;S:ssid;;
      ssid|password
      ssid\\npassword
    """
    if not payload:
        return None
    text = payload.strip()
    if not text:
        return None

    upper = text.upper()
    if upper.startswith("WIFI:"):
        body = text[5:]
        if body.endswith(";;"):
            body = body[:-1]
        fields = {}
        parts = re.split(r"(?<!\\);", body)
        for part in parts:
            part = part.strip()
            if not part or ":" not in part:
                continue
            key, val = part.split(":", 1)
            key = key.strip().upper()
            fields[key] = _wifi_unescape(val)
        ssid = fields.get("S", "").strip()
        if not ssid:
            return None
        t = fields.get("T", "WPA").strip().upper()
        password = fields.get("P", "")
        if t in ("NOPASS", "NONE", ""):
            password = ""
        return ssid, password

    if "|" in text:
        ssid, password = text.split("|", 1)
        ssid = ssid.strip()
        if ssid:
            return ssid, password.strip()
        return None

    if "\n" in text:
        lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
        if len(lines) >= 2:
            return lines[0], lines[1]
        if len(lines) == 1:
            return lines[0], ""
        return None

    return None


def wifi_connect(ssid, password):
    """连热点；成功返回 ip 字符串，失败返回 None。"""
    try:
        from maix import network, err as maix_err
    except Exception as e:
        print("[ball] wifi module missing:", e)
        return None
    try:
        w = network.wifi.Wifi()
        try:
            w.disconnect()
        except Exception:
            pass
        print("[ball] wifi connect ssid=%r ..." % ssid)
        e = w.connect(ssid, password or "", wait=True, timeout=int(WIFI_CONNECT_TIMEOUT))
        ok = False
        try:
            ok = (e == maix_err.Err.ERR_NONE) or (e == 0) or (e is None)
        except Exception:
            ok = e in (0, None) or str(e) in ("0", "ERR_NONE", "None")
        if not ok:
            # 部分固件 connect 返回值不标准，再看 is_connected / IP
            try:
                ok = bool(w.is_connected())
            except Exception:
                ok = False
        ip = ""
        try:
            ip = w.get_ip() or ""
        except Exception:
            ip = ""
        if not ip or ip in ("0.0.0.0", "127.0.0.1"):
            ip = get_ip()
        if ip and ip not in ("0.0.0.0", "127.0.0.1"):
            print("[ball] wifi ok ip=%s" % ip)
            return ip
        print("[ball] wifi connect fail ret=%r ip=%r" % (e, ip))
        return None
    except Exception as e:
        print("[ball] wifi connect err:", e)
        return None


def phase_scan_wifi(disp, cam, ts, allow_skip=True, title="Scan WiFi QR"):
    """
    扫 WiFi 二维码并连接。
    成功返回 ip；Skip 返回 ""；app 退出返回 None。
    """
    print("[ball] phase: scan WiFi QR (skip=%s)" % allow_skip)
    status = "Aim at WiFi QR"
    status_col = image.COLOR_WHITE
    last_fail_ms = 0
    connecting = False
    pressed_last = False
    dw, dh = disp.width(), disp.height()

    while not app.need_exit():
        try:
            img = cam.read()
            iw, ih = img.width(), img.height()
            skip_btn = [iw - 78, ih - 36, 72, 30] if allow_skip else None

            if not connecting:
                qrcodes = []
                try:
                    qrcodes = img.find_qrcodes()
                except Exception as e:
                    status = "QR err"
                    status_col = image.COLOR_RED
                    print("[ball] find_qrcodes:", e)

                for qr in qrcodes:
                    try:
                        corners = qr.corners()
                        for i in range(4):
                            x0, y0 = corners[i][0], corners[i][1]
                            x1, y1 = corners[(i + 1) % 4][0], corners[(i + 1) % 4][1]
                            img.draw_line(x0, y0, x1, y1, _rgb(UI_OK), 2)
                    except Exception:
                        pass
                    try:
                        payload = qr.payload()
                    except Exception:
                        payload = ""
                    parsed = parse_wifi_qr(payload)
                    if parsed is None:
                        status = "Not WiFi QR"
                        status_col = _rgb(UI_SP)
                        continue
                    ssid, password = parsed
                    status = "Connecting..."
                    status_col = _rgb(UI_FPS)
                    img.draw_string(6, 4, title, image.COLOR_WHITE, scale=1.1)
                    img.draw_string(6, 28, status + " " + ssid[:16], status_col, scale=1.0)
                    if skip_btn is not None:
                        draw_btn(img, skip_btn, "Skip")
                    disp.show(img)
                    connecting = True
                    print("[ball] QR ssid=%r" % ssid)
                    ip = wifi_connect(ssid, password)
                    connecting = False
                    if ip:
                        img2 = cam.read()
                        img2.draw_string(6, 4, "WiFi OK", _rgb(UI_OK), scale=1.2)
                        img2.draw_string(6, 30, ip, image.COLOR_WHITE, scale=1.1)
                        img2.draw_string(6, 54, "ssid: " + ssid[:22], image.COLOR_WHITE, scale=1.0)
                        disp.show(img2)
                        time.sleep_ms(600)
                        return ip
                    status = "Fail, rescan"
                    status_col = image.COLOR_RED
                    last_fail_ms = time.ticks_ms()
                    break

            # 取景辅助框
            m = 28
            img.draw_rect(m, m, max(8, iw - 2 * m), max(8, ih - 2 * m - 40),
                          _rgb(UI_ROI), 1)
            img.draw_string(6, 4, title, image.COLOR_WHITE, scale=1.1)
            img.draw_string(6, 28, status, status_col, scale=1.0)
            img.draw_string(6, 50, "WIFI:T:WPA;S:..;P:..;;", _rgb(UI_TEXT_DIM), scale=0.9)
            if skip_btn is not None:
                draw_btn(img, skip_btn, "Skip")
            disp.show(img)

            tx, ty, pressed = ts.read()
            mx, my = map_touch_to_image(tx, ty, iw, ih, dw, dh)
            if pressed and not pressed_last and skip_btn is not None:
                if is_in_button(mx, my, skip_btn):
                    print("[ball] WiFi skip")
                    return ""
            pressed_last = pressed

            if last_fail_ms and (time.ticks_ms() - last_fail_ms) > 2500:
                if status.startswith("Fail"):
                    status = "Aim at WiFi QR"
                    status_col = image.COLOR_WHITE
                last_fail_ms = 0
        except Exception as e:
            print("[ball] wifi scan loop:", e)
            time.sleep_ms(100)

    return None


def phase_ensure_wifi(disp, cam, ts, force_scan=False):
    """
    启动/重连 WiFi。
    已连接且非强制扫码 → 直接复用；否则扫码（可 Skip）。
    返回 ip 字符串；Skip/无网返回 ""；退出返回 None。
    """
    global _wifi_ip
    if not force_scan:
        ip = wifi_current_ip()
        if ip:
            print("[ball] wifi reuse ip=%s" % ip)
            _wifi_ip = ip
            img = cam.read()
            img.draw_string(6, 4, "WiFi ready", _rgb(UI_OK), scale=1.2)
            img.draw_string(6, 30, ip, image.COLOR_WHITE, scale=1.1)
            img.draw_string(6, 54, "Using existing network", _rgb(UI_TEXT_DIM), scale=1.0)
            disp.show(img)
            time.sleep_ms(500)
            return ip
        print("[ball] wifi not connected, enter scan")
    else:
        print("[ball] wifi force rescan")

    title = "Reconnect WiFi" if force_scan else "Scan WiFi QR"
    ip = phase_scan_wifi(disp, cam, ts, allow_skip=True, title=title)
    if ip is None:
        return None
    _wifi_ip = ip if ip else ""
    return ip


def apply_stream_for_ip(ip):
    """有有效 IP 则启 MJPEG；否则关图传。返回是否启用。"""
    global _stream_ready, _wifi_ip
    _wifi_ip = ip or ""
    if ip:
        url = start_mjpeg_server()  # 内部先 stop 再起
        _stream_ready = bool(url) and ENABLE_MJPEG
        if _stream_ready:
            print("[ball] stream on", url)
        else:
            print("[ball] stream start fail, detection only")
        return _stream_ready
    stop_mjpeg_server()
    print("[ball] no wifi → stream disabled")
    return False


def get_ip():
    try:
        import subprocess
        out = subprocess.check_output(["ifconfig", "wlan0"], stderr=subprocess.DEVNULL)
        text = out.decode(errors="ignore")
        m = re.search(r"inet addr:(\d+\.\d+\.\d+\.\d+)", text)
        if not m:
            m = re.search(r"inet (\d+\.\d+\.\d+\.\d+)", text)
        if m:
            ip = m.group(1)
            if ip not in ("0.0.0.0", "127.0.0.1"):
                return ip
    except Exception as e:
        print("[ball] ifconfig skip:", e)
    try:
        from maix import network
        ip = network.wifi.Wifi().get_ip()
        if ip and ip not in ("0.0.0.0", "127.0.0.1", ""):
            return ip
    except Exception as e:
        print("[ball] wifi get_ip skip:", e)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if ip and not ip.startswith("127."):
            return ip
    except Exception as e:
        print("[ball] socket ip skip:", e)
    return "0.0.0.0"


def img_to_jpeg_bytes(img, quality):
    try:
        jpg = img.to_jpeg(quality=quality)
    except TypeError:
        try:
            jpg = img.to_jpeg()
        except Exception:
            jpg = img.to_format(image.Format.FMT_JPEG)
    if hasattr(jpg, "to_bytes"):
        try:
            return jpg.to_bytes()
        except TypeError:
            return jpg.to_bytes(True)
    return bytes(jpg)


def _img_copy(img):
    try:
        return img.copy()
    except Exception:
        pass
    try:
        return img.to_format(img.format())
    except Exception:
        return None


def submit_mjpeg(img):
    """主线程只入队；JPEG 在 worker 编码。无 WiFi/无客户端或 worker 忙则跳过。"""
    global _mjpeg_pending, _mjpeg_jpeg
    if not ENABLE_MJPEG or not _stream_ready or _mjpeg_clients <= 0:
        return
    with _mjpeg_pending_lock:
        if _mjpeg_pending is not None:
            return
        copied = _img_copy(img)
        if copied is None:
            try:
                raw = img_to_jpeg_bytes(img, JPEG_QUALITY)
                with _mjpeg_lock:
                    _mjpeg_jpeg = raw
            except Exception as e:
                print("[ball] jpeg err:", e)
            return
        _mjpeg_pending = copied
    _mjpeg_wake.set()


def _jpeg_worker_loop():
    global _mjpeg_jpeg, _mjpeg_pending
    while not _mjpeg_stop:
        _mjpeg_wake.wait(timeout=0.2)
        _mjpeg_wake.clear()
        if _mjpeg_stop:
            break
        img = None
        with _mjpeg_pending_lock:
            img = _mjpeg_pending
            _mjpeg_pending = None
        if img is None:
            continue
        try:
            raw = img_to_jpeg_bytes(img, JPEG_QUALITY)
            with _mjpeg_lock:
                _mjpeg_jpeg = raw
        except Exception as e:
            print("[ball] jpeg err:", e)


class _MjpegHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return

    def do_GET(self):
        global _mjpeg_clients
        path = self.path.split("?")[0]
        if path in ("/", "/stream"):
            self.send_response(200)
            self.send_header(
                "Content-Type", "multipart/x-mixed-replace; boundary=frame"
            )
            self.send_header("Cache-Control", "no-store")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            with _mjpeg_lock:
                _mjpeg_clients += 1
            try:
                while not _mjpeg_stop and not app.need_exit():
                    with _mjpeg_lock:
                        frame = _mjpeg_jpeg
                    if not frame:
                        pytime.sleep(0.05)
                        continue
                    try:
                        self.wfile.write(
                            b"--frame\r\n"
                            b"Content-Type: image/jpeg\r\n\r\n" + frame + b"\r\n"
                        )
                        self.wfile.flush()
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        break
                    pytime.sleep(0.03)
            except Exception as e:
                print("[ball] mjpeg client end:", e)
            finally:
                with _mjpeg_lock:
                    _mjpeg_clients = max(0, _mjpeg_clients - 1)
            return
        self.send_error(404)


def start_mjpeg_server():
    global _mjpeg_server, _mjpeg_stop, _mjpeg_clients, _mjpeg_pending, _stream_ready
    if not ENABLE_MJPEG:
        _stream_ready = False
        return None
    stop_mjpeg_server()
    _mjpeg_stop = False
    _mjpeg_clients = 0
    with _mjpeg_pending_lock:
        _mjpeg_pending = None
    _mjpeg_wake.clear()
    try:
        server = ThreadingHTTPServer(("0.0.0.0", HTTP_PORT), _MjpegHandler)
        server.timeout = 0.5
        _mjpeg_server = server

        def _serve():
            while not _mjpeg_stop and not app.need_exit():
                try:
                    server.handle_request()
                except Exception:
                    break
            try:
                server.server_close()
            except Exception:
                pass

        threading.Thread(target=_jpeg_worker_loop, name="jpeg", daemon=True).start()
        threading.Thread(target=_serve, name="mjpeg", daemon=True).start()
        ip = _wifi_ip or get_ip()
        url = "http://{}:{}/stream".format(ip, HTTP_PORT)
        _stream_ready = True
        print("[ball] MJPEG:", url, "jpeg-async clients-gated")
        return url
    except Exception as e:
        print("[ball] MJPEG server fail:", e)
        _mjpeg_server = None
        _stream_ready = False
        return None


def stop_mjpeg_server():
    global _mjpeg_stop, _mjpeg_server, _mjpeg_pending, _mjpeg_clients, _stream_ready
    _stream_ready = False
    _mjpeg_stop = True
    _mjpeg_wake.set()
    with _mjpeg_pending_lock:
        _mjpeg_pending = None
    _mjpeg_clients = 0
    srv = _mjpeg_server
    _mjpeg_server = None
    if srv is not None:
        try:
            srv.server_close()
        except Exception:
            pass


def setup_display():
    disp = display.Display()
    try:
        image.load_font(
            "sourcehansans",
            "/maixapp/share/font/SourceHanSansCN-Regular.otf",
            size=18,
        )
        image.set_default_font("sourcehansans")
    except Exception as e:
        print("[ball] font:", e)
    print("[ball] display", disp.width(), "x", disp.height())
    return disp


def show_boot(disp, msg):
    img = image.Image(disp.width(), disp.height())
    img.draw_rect(0, 0, disp.width(), disp.height(), image.COLOR_BLACK, -1)
    img.draw_string(10, disp.height() // 2 - 10, msg, image.COLOR_WHITE, scale=1.3)
    disp.show(img)


def setup_uart_safe():
    if not ENABLE_UART or not HAS_UART_MOD:
        print("[ball] UART disabled")
        return None
    try:
        device_id = sys.device_id()
        print("[ball] device_id:", device_id)
        print("[ball] uart list:", uart.list_devices())

        if device_id == "maixcam2":
            pins = {"A21": "UART4_TX", "A22": "UART4_RX"}
            device = "/dev/ttyS4"
        else:
            # maixcam / maixcam-pro
            pins = {"A16": "UART0_TX", "A17": "UART0_RX"}
            device = "/dev/ttyS0"

        for pin, func in pins.items():
            ret = pinmap.set_pin_function(pin, func)
            if ret != err.Err.ERR_NONE:
                print(f"[ball] pinmap warn {pin}->{func}: {ret}")
            else:
                print(f"[ball] pinmap {pin}->{func}")

        ser = uart.UART(device, BAUD)
        # 文本握手：MCU 状态机忽略非 AA 55
        ser.write_str("BALL ready\r\n")
        print("[ball] UART open", device, BAUD, "-> balance PA31 RX")
        return ser
    except Exception as e:
        print("[ball] UART fail (continue without):", e)
        return None


def _i16(v):
    v = int(round(v))
    if v > 32767:
        return 32767
    if v < -32768:
        return -32768
    return v


def _frame_with_csum(body: bytes) -> bytes:
    """body 必须 10 字节（type..末字段），返回 13 字节整帧。"""
    assert len(body) == 10
    return bytes([PROTO_MAGIC0, PROTO_MAGIC1]) + body + bytes([sum(body) & 0xFF])


def clamp_roi(x, y, w, h, iw, ih):
    x = max(0, min(int(x), max(0, iw - 1)))
    y = max(0, min(int(y), max(0, ih - 1)))
    w = max(8, min(int(w), iw - x))
    h = max(8, min(int(h), ih - y))
    return x, y, w, h


def px_to_mm(cx_roi, roi_w, o_px, bar_len_mm):
    if roi_w <= 1:
        return 0.0
    return (float(cx_roi) - float(o_px)) * (bar_len_mm / float(roi_w))


def _best_blob(mask, gray=None):
    """在 mask 里找最像钢珠的斑（细 ROI 下形态学要轻，避免球被腐蚀没）。"""
    # 细框 H≈16：只用 1 次 close 粘连，open 用 2x2 以免抹掉小球
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, _K_CLOSE, iterations=1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, _K_OPEN, iterations=1)
    cnts = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = cnts[0] if len(cnts) == 2 else cnts[1]
    best = None
    h = mask.shape[0]
    y_mid = h * 0.5
    target_area = 3.1416 * (BALL_DIAM_PX * 0.5) ** 2

    for c in contours:
        area = cv2.contourArea(c)
        if area < MIN_AREA or area > MAX_AREA:
            continue
        x, y, bw, bh = cv2.boundingRect(c)
        if bw < 1 or bh < 1:
            continue
        # 细 ROI 里球常被裁成扁椭圆
        aspect = max(bw, bh) / float(min(bw, bh))
        if aspect > MAX_ASPECT:
            continue
        peri = cv2.arcLength(c, True)
        if peri < 1e-3:
            continue
        circ = 4.0 * 3.14159265 * area / (peri * peri)
        if circ < MIN_CIRCULARITY:
            continue
        m = cv2.moments(c)
        if m["m00"] < 1e-3:
            continue
        cx = m["m10"] / m["m00"]
        cy = m["m01"] / m["m00"]

        size_score = 30.0 * max(0.0, 1.0 - abs(area - target_area) / max(target_area, 1.0))
        y_score = Y_CENTER_WEIGHT * max(0.0, 1.0 - abs(cy - y_mid) / max(y_mid, 1.0))
        dark_score = 0.0
        if gray is not None:
            x0 = max(0, int(cx) - 2)
            x1 = min(gray.shape[1], int(cx) + 3)
            y0 = max(0, int(cy) - 2)
            y1 = min(gray.shape[0], int(cy) + 3)
            patch = gray[y0:y1, x0:x1]
            if patch.size > 0:
                dark_score = max(0.0, (180.0 - float(patch.mean())) / 180.0 * 20.0)
        score = circ * 50.0 + size_score + y_score + dark_score
        if best is None or score > best[0]:
            best = (score, cx, cy, area, (x, y, bw, bh))
    return best


def _proj_dark_on_bar(gray, bar_mask):
    """白杆上沿轴向找最暗谷（钢珠）；ROI 全宽有效，仅避开卷积半窗。"""
    h, w = gray.shape[:2]
    if w < 4 or h < 2:
        return None
    g = gray.astype(np.float32)
    # 非杆区域抬高，避免干扰
    g = np.where(bar_mask > 0, g, 255.0)
    proj = g.mean(axis=0)
    win = max(3, int(BALL_DIAM_PX) | 1)
    half = win // 2
    kernel = np.ones(win, dtype=np.float32) / float(win)
    smooth = np.convolve(proj, kernel, mode="same")
    lo, hi = half, w - half
    if hi <= lo + 2:
        lo, hi = 0, w
    if hi <= lo:
        return None
    # 只在杆像素足够的列上找
    col_ok = (bar_mask > 0).sum(axis=0) >= max(2, h // 4)
    seg = smooth[lo:hi].copy()
    for i in range(lo, hi):
        if i < len(col_ok) and not col_ok[i]:
            seg[i - lo] = 1e6
    if float(np.min(seg)) >= 1e5:
        return None
    idx = int(np.argmin(seg)) + lo
    val = float(smooth[idx])
    base = float(np.median(smooth[col_ok])) if col_ok.any() else float(np.median(smooth[lo:hi]))
    contrast = base - val  # 球应比杆暗
    if contrast < float(PROJ_MIN_CONTRAST):
        return None
    # y：该列杆像素的中心
    col = bar_mask[:, idx]
    ys = np.where(col > 0)[0]
    cy = float(ys.mean()) if len(ys) else h * 0.5
    score = min(95.0, 25.0 + contrast * float(PROJ_SCORE_SCALE))
    return (score, float(idx), cy)


def detect_ball(bgr, roi, mode):
    """
    针对白 PPR 凹槽 + 深色钢珠：
      1) 先提白色摆杆区域
      2) 在杆上找暗色小圆 / 轴向暗谷
    """
    ih, iw = bgr.shape[0], bgr.shape[1]
    rx, ry, rw, rh = clamp_roi(roi[0], roi[1], roi[2], roi[3], iw, ih)
    crop = bgr[ry:ry + rh, rx:rx + rw]
    if crop is None or crop.size == 0:
        return _empty(mode)

    if len(crop.shape) == 3:
        gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    else:
        gray = crop
    # 细 ROI 轻度模糊即可
    gray = cv2.GaussianBlur(gray, (3, 3), 0)

    # 白色摆杆掩膜（固定 ROI 用预计算核，避免 H=16 时 open 掏空）
    _, bar_mask = cv2.threshold(gray, TH_BAR_WHITE, 255, cv2.THRESH_BINARY)
    bar_mask = cv2.morphologyEx(bar_mask, cv2.MORPH_CLOSE, _K_BAR, iterations=1)
    if gray.shape[0] >= 12:
        bar_mask = cv2.morphologyEx(bar_mask, cv2.MORPH_OPEN, _K_BAR, iterations=1)

    candidates = []
    modes = (0, 1) if mode == 2 else (mode,)
    for mu in modes:
        if mu == 0:
            _, msk = cv2.threshold(gray, TH_BRIGHT, 255, cv2.THRESH_BINARY)
            msk = cv2.bitwise_and(msk, bar_mask)
        else:
            # 暗球：阈值 + 相对杆面偏暗；bar 大膨胀，球挖空处仍保留
            bar_dil = cv2.dilate(bar_mask, _K_BAR_DIL)
            _, dark = cv2.threshold(gray, TH_DARK, 255, cv2.THRESH_BINARY_INV)
            # 补充：比局部中值更暗（细框内绝对阈值常不够）
            med = cv2.medianBlur(gray, 5)
            diff = cv2.subtract(med, gray)  # 正值 = 比邻域暗
            _, rel = cv2.threshold(diff, 10, 255, cv2.THRESH_BINARY)
            dark = cv2.bitwise_or(dark, rel)
            msk = cv2.bitwise_and(dark, bar_dil)
        blob = _best_blob(msk, gray)
        if blob is not None:
            candidates.append((blob, mu, "blob"))

    if candidates:
        # ROI 全宽有效，不再做左右/行程死区过滤
        best, mode_used, via = max(candidates, key=lambda t: t[0][0])
        score, cx_r, cy_r, _area, bbox_r = best
        bx, by, bw, bh = bbox_r
        pmm = px_to_mm(cx_r, rw, O_OFFSET_PX, BAR_LEN_MM)
        return {
            "found": True,
            "cx": int(round(cx_r + rx)),
            "cy": int(round(cy_r + ry)),
            "pos_mm": pmm,
            "conf": int(max(0, min(100, score))),
            "bbox": (bx + rx, by + ry, bw, bh),
            "mode_used": mode_used,
            "via": via,
        }

    if not ENABLE_PROJ_FALLBACK:
        return _empty(mode)

    pk = _proj_dark_on_bar(gray, bar_mask)
    if pk is None:
        return _empty(mode)

    score, cx_r, cy_r = pk
    pmm = px_to_mm(cx_r, rw, O_OFFSET_PX, BAR_LEN_MM)
    r = max(4, BALL_DIAM_PX // 2)
    cx = int(round(cx_r + rx))
    cy = int(round(cy_r + ry))
    return {
        "found": True,
        "cx": cx,
        "cy": cy,
        "pos_mm": pmm,
        "conf": int(max(0, min(100, score))),
        "bbox": (cx - r, cy - r, r * 2, r * 2),
        "mode_used": 1,
        "via": "proj",
    }


def _empty(mode):
    return {
        "found": False,
        "cx": 0,
        "cy": 0,
        "pos_mm": 0.0,
        "conf": 0,
        "bbox": None,
        "mode_used": mode,
        "via": "none",
    }


def quantize_mm(pos_f, last_i, has_last):
    """浮点 mm → 整 mm；带滞回，减少 ±1mm 来回跳。"""
    if not has_last:
        return int(round(pos_f))
    # 仍在 last±HYST 内则保持
    if abs(pos_f - float(last_i)) < float(POS_HYST_MM):
        return int(last_i)
    return int(round(pos_f))


def update_track(det, now_ms, track):
    """Reject isolated ROI jumps with a one-dimensional constant-velocity predictor."""
    usable = bool(det["found"]) and int(det["conf"]) >= CONF_MIN
    if not usable:
        track["lost"] += 1
        if track["has"] and track["lost"] <= TRACK_HOLD_FRAMES:
            dt = max(0.03, min(0.20, (now_ms - track["last_ms"]) / 1000.0))
            predicted = track["pos"] + track["vel"] * dt
            track["pos"] = predicted
            track["last_ms"] = now_ms
            det["found"] = True
            det["conf"] = CONF_MIN
            det["pos_mm"] = predicted
            det["cx"] = mm_to_roi_x(predicted, [ROI_X, ROI_Y, ROI_W, ROI_H])
            det["cy"] = ROI_Y + ROI_H // 2
            return True
        track["has"] = False
        track["vel"] = 0.0
        return False

    raw_pos = float(det["pos_mm"])
    if not track["has"]:
        track["pos"] = raw_pos
        track["vel"] = 0.0
        track["last_ms"] = now_ms
        track["lost"] = 0
        track["has"] = True
        return True

    dt = max(0.03, min(0.20, (now_ms - track["last_ms"]) / 1000.0))
    predicted = track["pos"] + track["vel"] * dt
    innovation = raw_pos - predicted
    max_jump = TRACK_MAX_JUMP_MM + abs(track["vel"]) * dt
    if abs(innovation) > max_jump:
        track["lost"] += 1
        if track["lost"] <= TRACK_HOLD_FRAMES:
            track["pos"] = predicted
            track["last_ms"] = now_ms
            det["pos_mm"] = predicted
            det["conf"] = CONF_MIN
            det["cx"] = mm_to_roi_x(predicted, [ROI_X, ROI_Y, ROI_W, ROI_H])
            det["cy"] = ROI_Y + ROI_H // 2
            return True
        track["has"] = False
        track["vel"] = 0.0
        return False

    updated_pos = predicted + POS_ALPHA * innovation
    measured_vel = (updated_pos - track["pos"]) / dt
    track["vel"] += TRACK_VEL_ALPHA * (measured_vel - track["vel"])
    track["pos"] = updated_pos
    track["last_ms"] = now_ms
    track["lost"] = 0
    det["pos_mm"] = updated_pos
    return True


def pack_ball_frame(found, pos_mm, cx, cy, conf, mode):
    """type=0x02；pos_mm 为整毫米（线格式 i16，单位 1mm）。"""
    conf_i = max(0, min(100, int(conf)))
    usable = bool(found) and conf_i >= CONF_MIN
    flags = PROTO_FLAG_FOUND if usable else 0x00
    pos_i = int(pos_mm) if usable else 0
    body = struct.pack(
        "<BBhhhBB",
        PROTO_TYPE_BALL,
        flags,
        _i16(pos_i),
        _i16(cx) if usable else 0,
        _i16(cy) if usable else 0,
        conf_i if usable else 0,
        max(0, min(255, int(mode))),
    )
    return _frame_with_csum(body)


def pack_setpoint_frame(target_mm):
    """type=0x12 停球定点，单位整 mm。"""
    body = struct.pack("<BBh", PROTO_TYPE_SETPOINT, 0x00, _i16(int(round(target_mm)))) + bytes(6)
    return _frame_with_csum(body)


def uart_write(ser, data: bytes) -> bool:
    if ser is None or not data:
        return False
    try:
        ser.write(data)
        return True
    except Exception as e:
        print("[ball] UART write fail:", e)
        return False


def mm_to_roi_x(pos_mm, roi):
    """O 相对 mm → 画面 x。"""
    rx, _ry, rw, _rh = roi
    if BAR_LEN_MM <= 1e-6 or rw <= 1:
        return rx + O_OFFSET_PX
    cx_r = float(O_OFFSET_PX) + float(pos_mm) * (float(rw) / BAR_LEN_MM)
    return int(round(rx + cx_r))


def roi_x_to_mm(x, roi):
    """触摸 x → 相对 O 的 mm（可超框则钳位到杆长半幅）。"""
    rx, _ry, rw, _rh = roi
    if rw <= 1 or BAR_LEN_MM <= 1e-6:
        return 0
    cx_r = float(x) - float(rx)
    mm = (cx_r - float(O_OFFSET_PX)) * (BAR_LEN_MM / float(rw))
    if mm > SP_MAX_MM:
        return SP_MAX_MM
    if mm < SP_MIN_MM:
        return SP_MIN_MM
    return int(round(mm))


def is_in_button(x, y, btn):
    if btn is None:
        return False
    return btn[0] <= x <= btn[0] + btn[2] and btn[1] <= y <= btn[1] + btn[3]


def map_touch_to_image(tx, ty, img_w, img_h, disp_w, disp_h):
    """触摸在显示坐标 → 相机/叠加图像坐标（与 collect 一致）。"""
    if disp_w > 0 and disp_h > 0 and (disp_w != img_w or disp_h != img_h):
        return int(tx * img_w / disp_w), int(ty * img_h / disp_h)
    return int(tx), int(ty)


def layout_controls(img_w, img_h, menu_open=False):
    """
    底栏：Menu | Set | Reset
    折叠展开：Menu 上方竖排 WiFi / Exit
    """
    by = img_h - 36
    bh = 30
    gap = 6
    menu_btn = [6, by, 64, bh]
    set_btn = [menu_btn[0] + menu_btn[2] + gap, by, 72, bh]
    reset_btn = [set_btn[0] + set_btn[2] + gap, by, 72, bh]
    wifi_btn = None
    exit_btn = None
    if menu_open:
        item_w = 72
        exit_btn = [6, by - (bh + gap), item_w, bh]
        wifi_btn = [6, by - 2 * (bh + gap), item_w, bh]
    return {
        "menu": menu_btn,
        "set": set_btn,
        "reset": reset_btn,
        "wifi": wifi_btn,
        "exit": exit_btn,
        "bar_y": by,
    }


def layout_drag_strip(img_w, img_h, roi, bar_y):
    """Drag strip shown only in Set mode."""
    rx, ry, rw, rh = roi
    strip_y = min(bar_y - 34, ry + rh + 8)
    if strip_y < ry + rh + 2:
        strip_y = ry + rh + 2
    strip_h = 26
    if strip_y + strip_h > bar_y - 4:
        strip_h = max(18, bar_y - 4 - strip_y)
    return [rx, strip_y, rw, strip_h]


def hit_drag_zone(x, y, roi, drag_strip):
    """Bar or drag strip (Set mode only)."""
    rx, ry, rw, rh = roi
    if (rx - 4) <= x <= (rx + rw + 4) and (ry - 10) <= y <= (ry + rh + 10):
        return True
    return is_in_button(x, y, drag_strip)


def draw_btn(img, btn, label, active=False, danger=False, accent=False):
    if btn is None:
        return
    bx, by, bw, bh = btn
    if danger:
        bg = _rgb(UI_BG_DANGER)
        border = _rgb(UI_BORDER_DANGER)
    elif active:
        bg = _rgb(UI_BG_ACTIVE)
        border = _rgb(UI_BORDER_ACTIVE)
    elif accent:
        bg = _rgb(UI_BG_ACCENT)
        border = _rgb(UI_ROI)
    else:
        bg = _rgb(UI_BG)
        border = _rgb(UI_BORDER)
    img.draw_rect(bx, by, bw, bh, bg, -1)
    img.draw_rect(bx, by, bw, bh, border, 1)
    # 标签水平略居中
    tx = bx + max(4, (bw - len(label) * 8) // 2)
    img.draw_string(tx, by + 6, label, image.COLOR_WHITE, scale=1.0)


def draw_ui(img, roi, det, pos_mm_i, sp_mm, usable,
            btns, drag_strip, set_mode, dragging, menu_open, fps, stream_on, wifi_ip):
    """ROI + SP + FPS + 底栏 + 折叠 Menu(WiFi/Exit)。"""
    rx, ry, rw, rh = roi
    img.draw_rect(rx, ry, rw, rh, _rgb(UI_ROI), 1)

    ox = rx + O_OFFSET_PX
    img.draw_line(ox, ry - 6, ox, ry + rh + 6, _rgb(UI_O), 1)

    if set_mode:
        sx = mm_to_roi_x(sp_mm, roi)
        col_sp = _rgb(UI_SP)
        img.draw_line(sx, ry - 10, sx, ry + rh + 10, col_sp, 2)
        img.draw_circle(sx, ry + rh // 2, 5, col_sp, -1)

        dsx, dsy, dsw, dsh = drag_strip
        img.draw_rect(dsx, dsy, dsw, dsh, _rgb(UI_BG), -1)
        img.draw_rect(dsx, dsy, dsw, dsh, col_sp if dragging else _rgb(UI_BORDER), 1)
        img.draw_rect(max(dsx, sx - 4), dsy, 8, dsh, col_sp, -1)
        img.draw_string(dsx + 4, dsy + 4, "Drag to set", _rgb(UI_TEXT_DIM), scale=0.9)
    else:
        sx = mm_to_roi_x(sp_mm, roi)
        img.draw_line(sx, ry, sx, ry + rh, _rgb(UI_SP_DIM), 1)

    if usable and det.get("found"):
        img.draw_circle(int(det["cx"]), int(det["cy"]), 3, _rgb(UI_OK), -1)

    mode_tag = " SET" if set_mode else ""
    if usable:
        txt = "Ball {:+d} mm  SP {:+d} mm{}".format(pos_mm_i, sp_mm, mode_tag)
    else:
        txt = "Ball ----  SP {:+d} mm{}".format(sp_mm, mode_tag)
    img.draw_string(6, 4, txt, image.COLOR_WHITE, scale=1.05)

    # 右上：FPS + 图传状态
    if stream_on:
        net_txt = "Stream"
        net_col = _rgb(UI_OK)
    elif wifi_ip:
        net_txt = "WiFi"
        net_col = _rgb(UI_FPS)
    else:
        net_txt = "NoNet"
        net_col = _rgb(UI_TEXT_DIM)
    img.draw_string(max(6, img.width() - 88), 4,
                    "{:4.1f}F".format(fps), _rgb(UI_FPS), scale=1.05)
    img.draw_string(max(6, img.width() - 88), 22, net_txt, net_col, scale=0.95)

    # 折叠菜单项（在底栏之上）
    if menu_open:
        # 半透明感：深色底板
        panel_x, panel_y = 4, btns["wifi"][1] - 4
        panel_w, panel_h = 76, (btns["bar_y"] - panel_y)
        img.draw_rect(panel_x, panel_y, panel_w, panel_h, _rgb(UI_BG), -1)
        img.draw_rect(panel_x, panel_y, panel_w, panel_h, _rgb(UI_BORDER), 1)
        draw_btn(img, btns["wifi"], "WiFi", accent=True)
        draw_btn(img, btns["exit"], "Exit", danger=True)

    draw_btn(img, btns["menu"], "Close" if menu_open else "Menu", active=menu_open)
    draw_btn(img, btns["set"], "Done" if set_mode else "Set", active=set_mode)
    draw_btn(img, btns["reset"], "Reset")


def main():
    global _wifi_ip, _stream_ready

    disp = setup_display()
    show_boot(disp, "Ball control...")

    serial_dev = setup_uart_safe()
    cam = camera.Camera(CAM_W, CAM_H, image.Format.FMT_BGR888)
    print("[ball] camera", cam.width(), "x", cam.height(), "bar", BAR_LEN_MM, "mm")
    print("[ball] display", disp.width(), "x", disp.height())

    ts = touchscreen.TouchScreen()

    # 已连 WiFi → 复用；未连 → 扫码（可 Skip，无网则禁图传）
    ip = phase_ensure_wifi(disp, cam, ts, force_scan=False)
    if app.need_exit() or ip is None:
        print("[ball] exit before main")
        return
    apply_stream_for_ip(ip)

    roi = [ROI_X, ROI_Y, ROI_W, ROI_H]
    mode = DETECT_MODE
    pos_filt = 0.0
    pos_mm_i = 0
    has_filt = False
    has_mm_i = False
    last_tx_ms = 0
    sp_mm = 0
    sp_pending = True
    set_mode = False
    dragging_sp = False
    menu_open = False
    pressed_last = False
    err_cnt = 0
    last_log_ms = 0
    track = {"has": False, "pos": 0.0, "vel": 0.0, "last_ms": 0, "lost": 0}
    frame_n = 0

    if serial_dev is not None:
        if uart_write(serial_dev, pack_setpoint_frame(sp_mm)):
            sp_pending = False
            print("[ball] SP sync 0 mm")

    print("[ball] UI: Menu(WiFi/Exit) | Set/Done | Reset  stream=%d" % int(_stream_ready))

    try:
        while not app.need_exit():
            try:
                img = cam.read()
                iw, ih = img.width(), img.height()
                bgr = image.image2cv(img, ensure_bgr=False, copy=False)

                roi[0], roi[1], roi[2], roi[3] = ROI_X, ROI_Y, ROI_W, ROI_H
                btns = layout_controls(iw, ih, menu_open)
                drag_strip = layout_drag_strip(iw, ih, roi, btns["bar_y"])
                det = detect_ball(bgr, roi, mode)
                now_ms = time.ticks_ms()
                track_usable = update_track(det, now_ms, track)

                usable = track_usable and bool(det["found"]) and int(det["conf"]) >= CONF_MIN
                if usable:
                    if not has_filt:
                        pos_filt = float(det["pos_mm"])
                        has_filt = True
                    else:
                        pos_filt = POS_ALPHA * float(det["pos_mm"]) + (1.0 - POS_ALPHA) * pos_filt
                    pos_mm_i = quantize_mm(pos_filt, pos_mm_i, has_mm_i)
                    has_mm_i = True
                else:
                    has_filt = False
                    has_mm_i = False
                    pos_filt = 0.0
                    pos_mm_i = 0

                # 控制优先：量化后立刻 UART，再画 UI / 编码 / 本机屏
                if serial_dev is not None and (now_ms - last_tx_ms) >= TX_MIN_MS:
                    if sp_pending:
                        if uart_write(serial_dev, pack_setpoint_frame(sp_mm)):
                            sp_pending = False
                    frame = pack_ball_frame(
                        usable,
                        pos_mm_i,
                        det["cx"] if usable else 0,
                        det["cy"] if usable else 0,
                        det["conf"] if det["found"] else 0,
                        mode,
                    )
                    uart_write(serial_dev, frame)
                    last_tx_ms = now_ms

                tx, ty, pressed = ts.read()
                mx, my = map_touch_to_image(tx, ty, iw, ih, disp.width(), disp.height())

                if pressed and not pressed_last:
                    hit_menu = is_in_button(mx, my, btns["menu"])
                    hit_set = is_in_button(mx, my, btns["set"])
                    hit_reset = is_in_button(mx, my, btns["reset"])
                    hit_wifi = menu_open and is_in_button(mx, my, btns["wifi"])
                    hit_exit = menu_open and is_in_button(mx, my, btns["exit"])
                    hit_any_chrome = hit_menu or hit_set or hit_reset or hit_wifi or hit_exit

                    if hit_menu:
                        menu_open = not menu_open
                        dragging_sp = False
                        print("[ball] menu ->", menu_open)
                    elif hit_exit:
                        print("[ball] Exit @", mx, my)
                        app.set_exit_flag(True)
                    elif hit_wifi:
                        menu_open = False
                        print("[ball] manual WiFi reconnect")
                        prev_ip = _wifi_ip
                        new_ip = phase_ensure_wifi(disp, cam, ts, force_scan=True)
                        if app.need_exit() or new_ip is None:
                            break
                        if new_ip:
                            apply_stream_for_ip(new_ip)
                        else:
                            # Skip：保留原连接/图传状态
                            keep = wifi_current_ip() or prev_ip
                            if keep and not _stream_ready:
                                apply_stream_for_ip(keep)
                            elif not keep:
                                apply_stream_for_ip("")
                            print("[ball] WiFi skip keep ip=%s stream=%d"
                                  % (keep or "-", int(_stream_ready)))
                        pressed_last = False
                        continue
                    elif hit_set:
                        set_mode = not set_mode
                        menu_open = False
                        dragging_sp = False
                        print("[ball] Set mode ->", set_mode)
                    elif hit_reset:
                        sp_mm = 0
                        sp_pending = True
                        set_mode = False
                        menu_open = False
                        dragging_sp = False
                        if serial_dev is not None:
                            uart_write(serial_dev, pack_setpoint_frame(0))
                            sp_pending = False
                        print("[ball] Reset SP=0")
                    elif menu_open and not hit_any_chrome:
                        menu_open = False
                    elif set_mode and (not menu_open) and hit_drag_zone(mx, my, roi, drag_strip):
                        dragging_sp = True
                        sp_mm = roi_x_to_mm(mx, roi)
                        sp_pending = True
                        if serial_dev is not None:
                            if uart_write(serial_dev, pack_setpoint_frame(sp_mm)):
                                sp_pending = False
                elif pressed and set_mode and dragging_sp and not menu_open:
                    new_sp = roi_x_to_mm(mx, roi)
                    if new_sp != sp_mm:
                        sp_mm = new_sp
                        sp_pending = True
                        if serial_dev is not None:
                            if uart_write(serial_dev, pack_setpoint_frame(sp_mm)):
                                sp_pending = False
                else:
                    if dragging_sp:
                        sp_pending = True
                    dragging_sp = False
                pressed_last = pressed

                fps = time.fps()
                draw_ui(
                    img, roi, det, pos_mm_i, sp_mm, usable,
                    btns, drag_strip, set_mode, dragging_sp, menu_open,
                    fps, _stream_ready, _wifi_ip,
                )
                frame_n += 1
                if _stream_ready and (MJPEG_EVERY_N <= 1 or (frame_n % MJPEG_EVERY_N) == 0):
                    submit_mjpeg(img)
                if DISP_EVERY_N <= 1 or (frame_n % DISP_EVERY_N) == 0:
                    disp.show(img)

                if (now_ms - last_log_ms) >= 1000:
                    last_log_ms = now_ms
                    print(
                        "[ball] pos=%+d sp=%+d set=%d menu=%d fps=%.1f stream=%d cli=%d ip=%s"
                        % (pos_mm_i, sp_mm, int(set_mode), int(menu_open), fps,
                           int(_stream_ready), _mjpeg_clients, _wifi_ip or "-")
                    )
            except Exception as e:
                err_cnt += 1
                print("[ball] loop err:", e)
                time.sleep_ms(200)
                if err_cnt > 30:
                    break
    finally:
        stop_mjpeg_server()
        if serial_dev is not None:
            uart_write(serial_dev, pack_ball_frame(False, 0, 0, 0, 0, mode))
        print("[ball] exit")


if __name__ == "__main__":
    main()
